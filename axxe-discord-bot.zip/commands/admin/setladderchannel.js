const { SlashCommandBuilder } = require('discord.js');
const mysql = require('mysql2/promise');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setladderchannel')
    .setDescription('Associar o canal Discord atual a uma ladder pelo nome da ladder')
    .addStringOption(option =>
      option.setName('ladder_name')
        .setDescription('O nome da ladder para associar a este canal')
        .setRequired(true)
        .setAutocomplete(true)),

  async execute(interaction) {
    if (interaction.isAutocomplete()) {
      const focusedValue = interaction.options.getFocused();
      const db = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
      });

      try {
        const [rows] = await db.execute(
          'SELECT name FROM ladders WHERE name LIKE ? LIMIT 25',
          [`%${focusedValue}%`]
        );

        await interaction.respond(
          rows.map(row => ({ name: row.name, value: row.name }))
        );
      } catch (error) {
        console.error('❌ Error fetching ladder names for autocomplete:', error);
        await interaction.respond([]);
      } finally {
        await db.end();
      }
      return;
    }

    // Check if user has admin permissions (this can be customized)
      if (!interaction.member.permissions.has('ADMINISTRATOR')) {
        return interaction.reply({ content: '❌ Não tem permissão para usar este comando.', ephemeral: true });
      }

    const ladderName = interaction.options.getString('ladder_name');
    const channel = interaction.channel;

    const db = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });

    try {
      // Find ladder_id by ladder name
      const [rows] = await db.execute(
        'SELECT id FROM ladders WHERE name = ?',
        [ladderName]
      );

        if (rows.length === 0) {
          await interaction.reply({ content: `❌ Ladder com o nome "${ladderName}" não encontrada.`, ephemeral: true });
          return;
        }

      const ladderId = rows[0].id;

      // Insert or update the mapping
      await db.execute(
        `INSERT INTO discord_channel_ladders (channel_id, ladder_id)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE ladder_id = VALUES(ladder_id)`,
        [channel.id, ladderId]
      );

      await interaction.reply({ content: `✅ Canal <#${channel.id}> foi associado à ladder "${ladderName}" (ID: ${ladderId}).`, ephemeral: false });
    } catch (error) {
      console.error('❌ Erro ao associar o canal à ladder:', error);
      await interaction.reply({ content: '❌ Falha ao associar o canal à ladder.', ephemeral: true });
    } finally {
      await db.end();
    }
  }
};
