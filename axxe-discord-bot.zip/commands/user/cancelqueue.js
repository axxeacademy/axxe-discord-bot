const { SlashCommandBuilder } = require('discord.js');
const mysql = require('mysql2/promise');
const { logCommand } = require('../../utils/logger');
const { getLadderIdByChannel } = require('../../utils/ladderChannelMapping');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cancelqueue')
    .setDescription('Remover-se da fila de matchmaking'),

  async execute(interaction) {
    const ladderId = await getLadderIdByChannel(interaction.channelId);
    if (!ladderId) {
      return await interaction.reply({
        content: '❌ Este comando não pode ser usado neste canal.',
        ephemeral: true
      });
    }

    await interaction.deferReply({ ephemeral: true });
    const user = interaction.user;

    const db = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });

    try {
      const [result] = await db.execute(
        'DELETE FROM ladder_match_queue WHERE discord_id = ?',
        [user.id]
      );

      if (result.affectedRows > 0) {
        await interaction.editReply({
          content: '✅ Saiu da fila de matchmaking.',
          ephemeral: true
        });
        await logCommand(interaction, `${interaction.user.tag} saiu da fila de matchmaking.`);
      } else {
        await interaction.editReply({
          content: '❌ Não estava na fila de matchmaking.',
          ephemeral: true
        });
        await logCommand(interaction, `${interaction.user.tag} tentou sair da fila mas não estava nela.`);
      }
    } catch (err) {
      console.error('❌ Erro em cancelqueue:', err);
      await interaction.editReply({
        content: '❌ Erro ao tentar sair da fila.',
        ephemeral: true
      });
    } finally {
      await db.end();
    }
  }
};
