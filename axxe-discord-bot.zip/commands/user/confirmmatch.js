// commands/user/confirmmatch.js
const { SlashCommandBuilder } = require('@discordjs/builders');
const { logCommand } = require('../../utils/logger');
const { getLadderIdByChannel } = require('../../utils/ladderChannelMapping');
const matchService = require('../../services/matchService');
const { confirmationTimers } = require('./reportmatch');
const languageService = require('../../services/languageService');
const { getGamertagByDiscordId } = require('../../services/userService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('confirmmatch')
    .setDescription('Confirmar o resultado de um jogo.'),

  async execute(interaction) {
    const thread = interaction.channel;

    async function safeReply(content, options) {
      if (thread.archived) {
        try { await thread.setArchived(false); } catch (err) { console.error('❌ Failed to unarchive thread before reply:', err); }
      }
      if (interaction.replied) {
        return interaction.followUp(content, options);
      } else if (interaction.deferred) {
        return interaction.editReply(content, options);
      } else {
        return interaction.reply(content, options);
      }
    }

    if (!thread.isThread()) {
      return safeReply({ content: languageService.getMessage('pt-PT', 'command_not_in_thread'), ephemeral: true });
    }

    let ladderId = null;
    if (interaction.channel.isThread()) {
      ladderId = await getLadderIdByChannel(interaction.channel.parentId);
    }
    if (!ladderId) {
      ladderId = await getLadderIdByChannel(interaction.channel.id);
    }
    if (!ladderId) {
      return safeReply({
        content: languageService.getMessage('pt-PT', 'command_not_in_channel'),
        ephemeral: true
      });
    }

    const matchIdMatch = thread.name.match(/^Match #(\d+)/);
    const matchId = matchIdMatch ? parseInt(matchIdMatch[1]) : NaN;

    try {
      // ... inside your execute() try block, right before calling matchService.confirmMatch:
      const confirmerDiscordId = interaction.user.id;
      const confirmerGamertag = await getGamertagByDiscordId(confirmerDiscordId);

      // Prefer gamertag from DB; fall back to Discord names if missing
      const confirmerName =
        confirmerGamertag ||
        interaction.user.globalName ||
        interaction.member?.displayName ||
        interaction.user.username;

      const success = await matchService.confirmMatch(
        interaction.client,
        matchId,
        ladderId,
        thread,
        { source: 'manual', confirmer: confirmerName }
      );
      if (success) {
        // Stop any running auto-confirm timers
        const timers = confirmationTimers.get(thread.id);
        if (timers) {
          clearInterval(timers.interval);
          clearTimeout(timers.timeout);
          confirmationTimers.delete(thread.id);
        }

        // Fetch match result for logging
        const matchDetails = await matchService.getMatchById(matchId);

        let matchResult = null;
        let eloGain = { player1: null, player2: null };
        let currentElo = { player1: null, player2: null };
        if (matchDetails) {
          matchResult = `${matchDetails.player1_score} - ${matchDetails.player2_score}`;

          const conn = await require('mysql2/promise').createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME,
          });

          const [eloRows] = await conn.execute(
            `SELECT player_id, delta, new_elo FROM ladder_elo_history WHERE match_id = ?`,
            [matchId]
          );
          await conn.end();

          if (eloRows.length === 2) {
            eloGain.player1 = eloRows[0].delta;
            eloGain.player2 = eloRows[1].delta;
            currentElo.player1 = eloRows[0].new_elo;
            currentElo.player2 = eloRows[1].new_elo;
          }
        }

        const conn2 = await require('mysql2/promise').createConnection({
          host: process.env.DB_HOST,
          user: process.env.DB_USER,
          password: process.env.DB_PASSWORD,
          database: process.env.DB_NAME,
        });

        const [player1Rows] = await conn2.execute(
          'SELECT gamertag, username as discordUsername, discord_id as discordUserId FROM users WHERE id = ?',
          [matchDetails.player1_id]
        );
        const [player2Rows] = await conn2.execute(
          'SELECT gamertag, username as discordUsername, discord_id as discordUserId FROM users WHERE id = ?',
          [matchDetails.player2_id]
        );
        await conn2.end();

        const player1 = player1Rows[0] || { gamertag: 'Unknown', discordUsername: 'Unknown', discordUserId: null };
        const player2 = player2Rows[0] || { gamertag: 'Unknown', discordUsername: 'Unknown', discordUserId: null };

        await logCommand(interaction, `Match confirmed manually in thread ${thread.name} by ${confirmerName}`, {
          threadId: thread.id,
          threadName: thread.name,
          matchResult: {
            result: `${player1.gamertag} ${matchDetails.player1_score} - ${matchDetails.player2_score} ${player2.gamertag}`,
            eloGain,
            currentElo
          },
          matchInfo: {
            player1,
            player2,
            threadId: thread.id
          }
        });

        await safeReply({ content: '✅ Jogo confirmado com sucesso.', ephemeral: false });
        if (!thread.archived) {
          try { await thread.setArchived(true); } catch (err) { console.error('❌ Falha ao arquivar a thread após a confirmação:', err); }
        }
      } else {
        await safeReply({ content: '❌ Falha na confirmação do jogo.', ephemeral: true });
      }
    } catch (error) {
      console.error('❌ Erro em /confirmmatch:', error);
      try { await safeReply({ content: '❌ Falha na confirmação do jogo.', ephemeral: true }); } catch (_) {}
    }
  }
};
