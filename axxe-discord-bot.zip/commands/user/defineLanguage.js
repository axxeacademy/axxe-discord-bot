
require('dotenv').config();
const { SlashCommandBuilder } = require('discord.js');
const mysql = require('mysql2/promise');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('definelanguage')
    .setDescription('Define a língua para as mensagens do bot')
    .addStringOption(option =>
      option.setName('language')
        .setDescription('Escolha a língua')
        .setRequired(true)
        .addChoices(
          { name: 'Português', value: 'pt-PT' },
          { name: 'English', value: 'en-EN' },
          { name: 'Español', value: 'es-ES' },
          { name: 'Français', value: 'fr-FR' },
          { name: 'Deutsch', value: 'de-DE' },
        )),
  async execute(interaction) {
    const language = interaction.options.getString('language');
    if (!language) {
      await interaction.reply({ content: 'Por favor, escolha uma língua válida.', ephemeral: true });
      return;
    }

    const userId = interaction.user.id;

    try {
      const conn = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
      });

      const [res] = await conn.execute(
        'UPDATE users SET language = ? WHERE discord_id = ?',
        [language, userId]
      );

      await conn.end();

      if (res.affectedRows === 0) {
        await interaction.reply({ content: 'Utilizador não encontrado na base de dados.', ephemeral: true });
        return;
      }

      await interaction.reply({ content: `Língua definida para: ${language}`, ephemeral: true });
    } catch (error) {
      console.error('Erro ao definir a língua:', error);
      await interaction.reply({ content: 'Ocorreu um erro ao definir a língua.', ephemeral: true });
    }
  },
};
