const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const mysql = require('mysql2/promise');
const dayjs = require('dayjs');

async function getLadderIdByChannel(db, channelId) {
  const [rows] = await db.execute(
    'SELECT ladder_id FROM discord_channel_ladders WHERE channel_id = ? LIMIT 1',
    [channelId]
  );
  return rows?.[0]?.ladder_id || null;
}

// Resolve user id from USERS table by gamertag (fallback username if you keep that behavior)
async function getUserIdByGamertag(db, gamertag) {
  const [rows] = await db.execute(
    `SELECT id
       FROM users
      WHERE gamertag = ? OR username = ?
      LIMIT 1`,
    [gamertag, gamertag]
  );
  return rows?.[0]?.id || null;
}

// Safe for ThreadMember objects where m.user may be null
async function getThreadHumanParticipants(interaction) {
  const members = await interaction.channel.members.fetch(); // Collection<string, ThreadMember>
  const humanIds = [];

  for (const [, m] of members) {
    const userId = m?.user?.id ?? m?.id;
    if (!userId) continue;

    let isBot = false;
    if (m.user !== null && m.user !== undefined) {
      isBot = !!m.user.bot;
    } else {
      const u = await interaction.client.users.fetch(userId).catch(() => null);
      isBot = !!u?.bot;
    }
    if (!isBot) humanIds.push(userId);
  }
  return [...new Set(humanIds)];
}

// Expects: "Match #123 - Gamertag1 vs Gamertag2"
// Tolerates -, – or — between the ID and the names.
function parseFromThreadName(name) {
  const m = (name || '').match(/#(\d+)\s*[-–—]\s*(.+?)\s+vs\s+(.+)/i);
  if (!m) return { matchId: null, gamertags: [] };
  const matchId = parseInt(m[1], 10);
  const gamertags = [m[2].trim(), m[3].trim()];
  return { matchId, gamertags };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dispute')
    .setDescription('Dispute THIS match (must be used inside the private match thread).')
    .addStringOption(opt =>
      opt.setName('reason')
        .setDescription('Explain what went wrong (desync, wrong score, DC, cheating, etc.)')
        .setRequired(true)
    )
    .addAttachmentOption(opt =>
      opt.setName('screenshot')
        .setDescription('Optional proof (scoreboard, clips, etc.)')
        .setRequired(false)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    // 1) Must be inside a thread
    if (!interaction.channel || !interaction.channel.isThread()) {
      return interaction.editReply('❌ You can only use `/dispute` **inside the private match thread**.');
    }

    const db = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      multipleStatements: false
    });

    try {
      const reason = interaction.options.getString('reason').trim().slice(0, 2000);
      const attachment = interaction.options.getAttachment('screenshot') || null;

      // 2) Ladder from the parent channel
      const parentChannelId = interaction.channel.parentId;
      const ladderId = await getLadderIdByChannel(db, parentChannelId);
      if (!ladderId) {
        return interaction.editReply('❌ This thread is not under a configured ladder channel.');
      }

      // 3) Exactly two human participants in the thread
      const participants = await getThreadHumanParticipants(interaction);
      if (participants.length !== 2) {
        return interaction.editReply('⚠️ This match thread must have exactly **two players** present. Ask a mod if the opponent left.');
      }

      // 4) Parse "Match #ID - Gamertag1 vs Gamertag2"
      const { matchId, gamertags } = parseFromThreadName(interaction.channel.name);
      if (!matchId || gamertags.length !== 2) {
        return interaction.editReply('❌ Thread title must be `Match #123 - PlayerOne vs PlayerTwo`.');
      }

      const [aGamertag, bGamertag] = gamertags;

      // 5) Resolve users from USERS table
      const [aId, bId] = await Promise.all([
        getUserIdByGamertag(db, aGamertag),
        getUserIdByGamertag(db, bGamertag)
      ]);

      if (!aId || !bId) {
        return interaction.editReply('❌ Could not resolve one or both gamertags to registered users.');
      }

      // 6) Fetch the exact match by ID and validate ladder + players
      const [rows] = await db.execute(
        `SELECT id, player1_id, player2_id, ladder_id, player1_score, player2_score, status
           FROM ladder_matches
          WHERE id = ? LIMIT 1`,
        [matchId]
      );
      const m = rows?.[0] || null;
      if (!m) return interaction.editReply('❌ No match found with this ID.');
      if (m.ladder_id !== ladderId) {
        return interaction.editReply('❌ This match does not belong to this ladder/channel.');
      }

      const playersMatch =
        (aId === m.player1_id && bId === m.player2_id) ||
        (aId === m.player2_id && bId === m.player1_id);

      if (!playersMatch) {
        return interaction.editReply('❌ The players in the thread title do not match the players in the match record.');
      }

      // 7) Update the match to disputed (+ optional screenshot)
      const params = [];
      let updateSql = `UPDATE ladder_matches SET status = 'disputed'`;
      if (attachment?.url) {
        updateSql += `, screenshot_url = ?`;
        params.push(attachment.url);
      }
      updateSql += ` WHERE id = ? LIMIT 1`;
      params.push(matchId);

      await db.execute(updateSql, params);

      // 8) Audit log
      await db.execute(
        `INSERT INTO admin_audit_log (actor_discord_id, module, action, entity_type, entity_id, details)
         VALUES (?, 'matches', 'dispute.create', 'match', ?, JSON_OBJECT(
           'reason', ?, 'screenshotUrl', ?, 'ladderId', ?, 'channelId', ?, 'thread', true, 'at', ?
         ))`,
        [
          interaction.user.id,
          String(matchId),
          reason,
          attachment?.url || null,
          String(ladderId),
          String(interaction.channel.id),
          dayjs().toISOString()
        ]
      );

      // 9) Public ping inside this thread
      const embed = new EmbedBuilder()
        .setTitle(`🛑 Match #${matchId} flagged as DISPUTED`)
        .setDescription(reason || 'No reason provided.')
        .addFields(
          { name: 'Status', value: 'disputed', inline: true },
          { name: 'Scores', value: `${m.player1_score} – ${m.player2_score}`, inline: true }
        )
        .setFooter({ text: `Ladder ID: ${ladderId} • ${dayjs().format('YYYY-MM-DD HH:mm')}` });

      if (attachment?.url) embed.addFields({ name: 'Screenshot', value: attachment.url });

      const modRoleId = process.env.MOD_ROLE_ID || null;
      const mentionMods = modRoleId ? `<@&${modRoleId}> ` : '';
      await interaction.channel.send({
        content: `${mentionMods}⚠️ ${interaction.user} opened a dispute for **Match #${matchId}**.`,
        embeds: [embed]
      });

      await interaction.editReply('✅ Dispute filed for this match. Moderators have been notified.');

    } catch (err) {
      console.error('/dispute error:', err);
      try { await interaction.editReply('❌ Something went wrong while filing your dispute.'); } catch {}
    } finally {
      await db.end().catch(() => {});
    }
  }
};
