// commands/user/findmatch.js
require('dotenv').config();
const { SlashCommandBuilder } = require('discord.js');
const mysql = require('mysql2/promise');
const { logCommand } = require('../../utils/logger');
const { addToQueue, getNextOpponent, removeFromQueue } = require('../../services/queueService');
const { createMatch, createMatchThread } = require('../../services/matchService');
const { getLadderIdByChannel } = require('../../utils/ladderChannelMapping');
const languageService = require('../../services/languageService');

async function logPlayerPairing(interaction, player1, player2, thread) {
  await logCommand(interaction, `Players paired:`, {
    matchInfo: {
      player1: {
        gamertag: player1.gamertag,
        discordUsername: player1.username
      },
      player2: {
        gamertag: player2.gamertag,
        discordUsername: player2.username
      },
      threadId: thread.id
    }
  });
}



module.exports = {
  data: new SlashCommandBuilder()
    .setName('findmatch')
    .setDescription('Entrar na fila de matchmaking para encontrar um adversário.'),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const discordId = interaction.user.id;
    const username = interaction.user.tag;
    const channelId = interaction.channel.id;

    let ladderId = await getLadderIdByChannel(channelId);
    if (!ladderId) {
      return await interaction.editReply({
        content: '❌ Este comando não pode ser usado neste canal.',
        ephemeral: true,
      });
    }

    try {
      const conn = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
      });

      const [queueRows] = await conn.execute(
        'SELECT * FROM ladder_match_queue WHERE discord_id = ? AND competition_id = ? AND ladder_id = ?',
        [discordId, ladderId, ladderId]
      );
      if (queueRows.length > 0) {
        // playerRows is not defined yet here, so we need to fetch playerRows first before using it
        const [playerRows] = await conn.execute(
          'SELECT id, gamertag, language FROM users WHERE discord_id = ?',
          [discordId]
        );
        const userLanguage = playerRows[0]?.language || 'pt-PT';
        const message = '❌ Já está na fila de matchmaking.';
        await conn.end();
        return await interaction.editReply({
          content: message,
          ephemeral: true,
        });
      }

      const [playerRows] = await conn.execute(
        'SELECT id, gamertag, language FROM users WHERE discord_id = ?',
        [discordId]
      );
      if (playerRows.length === 0) {
        const message = '❌ Não está registado na ladder.';
        await conn.end();
        return await interaction.editReply({
          content: message,
          ephemeral: true
        });
      }

      const playerId = playerRows[0].id;
      const playerGamertag = playerRows[0].gamertag;

      if (!playerGamertag || playerGamertag.trim() === '') {
        await conn.end();
        const message = '❌ Precisa definir o seu gamertag antes de entrar na fila.\nPara definir o seu gamertag, use o comando `/ladder-setGamerTag`.';
        return await interaction.editReply({
          content: message,
          ephemeral: true
        });
      }

      // Ensure player_stats exists for this player and ladder
      const [statsRows] = await conn.execute(
        'SELECT player_id FROM ladder_player_stats WHERE player_id = ? AND competition_id = ? AND ladder_id = ?',
        [playerId, ladderId, ladderId]
      );
      if (statsRows.length === 0) {
        // Insert default stats (adjust fields as needed for your schema)
        await conn.execute(
          `INSERT INTO ladder_player_stats 
            (player_id, competition_id, ladder_id, elo_rating, games_played, wins, draws, losses, points, goals_scored, goals_conceded, goal_diff, win_streak, last_played)
           VALUES (?, ?, ?, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL)`,
          [playerId, ladderId, ladderId]
        );
      }

      // Fetch player's Elo and rank
      const [eloRows] = await conn.execute(
        `SELECT 
            ps.elo_rating AS elo,
            (SELECT COUNT(*) + 1 FROM ladder_player_stats WHERE elo_rating > ps.elo_rating AND competition_id = ? AND ladder_id = ?) AS 'rank'
          FROM ladder_player_stats ps
          WHERE ps.player_id = ? AND ps.competition_id = ? AND ps.ladder_id = ?`,
        [ladderId, ladderId, playerId, ladderId, ladderId]
      );
      const playerElo = eloRows[0]?.elo ?? null;

      const opponent = await getNextOpponent(discordId, playerElo, ladderId);

      if (opponent) {
        const [opponentRows] = await conn.execute(
          'SELECT id, gamertag FROM users WHERE discord_id = ?',
          [opponent.discord_id]
        );
        const opponentPlayerId = opponentRows[0]?.id;
        const opponentGamertag = opponentRows[0]?.gamertag;

        if (!opponentPlayerId) {
          return await interaction.editReply({
            content: '❌ Falha ao encontrar adversário.',
            ephemeral: true
          });
        }

        if (!opponentGamertag || opponentGamertag.trim() === '') {
          return await interaction.editReply({
            content: '❌ O adversário não tem gamertag definido.',
            ephemeral: true
          });
        }

        await removeFromQueue(discordId, ladderId);
        await removeFromQueue(opponent.discord_id, ladderId);

        const matchId = await createMatch(playerId, opponentPlayerId, ladderId);

        // Fetch gamertag for both players
        const [user1Rows] = await conn.execute(
          'SELECT gamertag FROM users WHERE discord_id = ?',
          [discordId]
        );
        const user1Gamertag = user1Rows[0]?.gamertag || playerGamertag;

        const [user2Rows] = await conn.execute(
          'SELECT gamertag FROM users WHERE discord_id = ?',
          [opponent.discord_id]
        );
        const user2Gamertag = user2Rows[0]?.gamertag || opponentGamertag;

        const thread = await createMatchThread(interaction, discordId, opponent.discord_id, matchId, user1Gamertag, user2Gamertag, { private: true });

        // Removed thread archiving to unclutter code as per user request
        // (No archiving here)

        // Delete the system message about thread creation in the main channel
        try {
          const fetchedMessages = await interaction.channel.messages.fetch({ limit: 5 });
          const systemMessage = fetchedMessages.find(msg =>
            msg.type === 11 && // THREAD_CREATED system message type
            msg.content.includes(`Match #${matchId} -`)
          );
          if (systemMessage) {
            await systemMessage.delete();
          }
        } catch (deleteError) {
          console.error('Failed to delete thread creation system message:', deleteError);
        }

        // Log the player pairing with gamertags, discord usernames, and thread link
        await logPlayerPairing(interaction, 
          { gamertag: user1Gamertag, username: username }, 
          { gamertag: user2Gamertag, username: opponent.discord_id }, 
          thread);

        await conn.end();

        return await interaction.editReply({
          content: `✅ Entrou na fila da ladder ${ladderId} — Elo: ${playerElo}, Classificação: #${eloRows[0]?.rank ?? 'N/A'}`,
          ephemeral: true
        });
      } else {
        await addToQueue(playerId, discordId, ladderId);

        const [eloRows] = await conn.execute(
          `SELECT 
              ps.elo_rating AS elo,
              (SELECT COUNT(*) + 1 FROM ladder_player_stats WHERE elo_rating > ps.elo_rating AND competition_id = ? AND ladder_id = ?) AS 'rank'
            FROM ladder_player_stats ps
            WHERE ps.player_id = ? AND ps.competition_id = ? AND ps.ladder_id = ?`,
          [ladderId, ladderId, playerId, ladderId, ladderId]
        );

        const elo = eloRows[0]?.elo ?? 'N/A';
        const rank = eloRows[0]?.rank ?? 'N/A';

        await conn.end();

        await interaction.editReply({
          content: `✅ Entrou na fila da ladder ${ladderId} — Elo: ${elo}, Classificação: #${rank}\n\nPara sair da fila, use o comando /cancelqueue.\nPara ver quantos jogadores estão na fila, use o comando /status.`,
          ephemeral: true
        });

        await logCommand(interaction, `${playerGamertag} entrou na fila de matchmaking da ladder ${ladderId} — Elo: ${elo}, Classificação: #${rank}`);
      }

    } catch (error) {
      console.error('❌ DB Error in /findmatch:', error);
      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.editReply({
            content: '❌ Ocorreu um erro ao tentar encontrar um adversário.',
            ephemeral: true
          });
        } else {
          await interaction.reply({
            content: '❌ Ocorreu um erro ao tentar encontrar um adversário.',
            ephemeral: true
          });
        }
      } catch (err) {
        console.error('❌ Secondary reply error:', err);
      }
    }
    }
};
