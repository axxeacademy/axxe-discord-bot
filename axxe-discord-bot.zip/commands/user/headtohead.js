const { SlashCommandBuilder } = require('discord.js');
const mysql = require('mysql2/promise');
const { getLadderIdByChannel } = require('../../utils/ladderChannelMapping');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('headtohead')
    .setDescription('See your record vs a specific opponent.')
    .addUserOption(option =>
      option.setName('opponent')
        .setDescription('The opponent to see your record against')
        .setRequired(true)
    ),

  async execute(interaction) {
    const ladderId = await getLadderIdByChannel(interaction.channelId);
    if (!ladderId) {
      return await interaction.reply({
        content: '❌ This command cannot be used in this channel.',
        ephemeral: true
      });
    }

    const user = interaction.user;
    const opponentUser = interaction.options.getUser('opponent');
    if (!opponentUser) {
      return await interaction.reply({
        content: '❌ You must specify an opponent user.',
        ephemeral: true
      });
    }

    if (opponentUser.id === user.id) {
      return await interaction.reply({
        content: '❌ You cannot check head-to-head against yourself.',
        ephemeral: true
      });
    }

    await interaction.deferReply({ ephemeral: true });

    const db = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });

    try {
      // Get player IDs for both users
      const [[playerRow]] = await db.execute(
        'SELECT id FROM users WHERE discord_id = ?',
        [user.id]
      );
      const [[opponentRow]] = await db.execute(
        'SELECT id FROM users WHERE discord_id = ?',
        [opponentUser.id]
      );

      if (!playerRow) {
        return await interaction.editReply('❌ You are not registered in the ladder.');
      }
      if (!opponentRow) {
        return await interaction.editReply('❌ The specified opponent is not registered in the ladder.');
      }

      const playerId = playerRow.id;
      const opponentId = opponentRow.id;

      // Query gamertags for both players
      const [[playerGamertagRow]] = await db.execute(
        'SELECT gamertag FROM users WHERE id = ?',
        [playerId]
      );
      const [[opponentGamertagRow]] = await db.execute(
        'SELECT gamertag FROM users WHERE id = ?',
        [opponentId]
      );
      const playerGamertag = playerGamertagRow ? playerGamertagRow.gamertag : null;
      const opponentGamertag = opponentGamertagRow ? opponentGamertagRow.gamertag : null;

      // Query head-to-head match results between player and opponent
      const [matches] = await db.execute(
        `SELECT 
          SUM(CASE WHEN (player1_id = ? AND player2_id = ? AND (player1_score > player2_score OR (player1_score = player2_score AND penalty_score1 > penalty_score2))) 
                   OR (player2_id = ? AND player1_id = ? AND (player2_score > player1_score OR (player2_score = player1_score AND penalty_score2 > penalty_score1))) THEN 1 ELSE 0 END) AS wins,
          SUM(CASE WHEN (player1_id = ? AND player2_id = ? AND (player1_score < player2_score OR (player1_score = player2_score AND penalty_score2 > penalty_score1))) 
                   OR (player2_id = ? AND player1_id = ? AND (player2_score < player1_score OR (player2_score = player1_score AND penalty_score1 > penalty_score2))) THEN 1 ELSE 0 END) AS losses,
          SUM(player1_score + player2_score) AS total_goals,
          SUM(CASE WHEN player1_id = ? THEN player1_score WHEN player2_id = ? THEN player2_score ELSE 0 END) AS goals_scored,
          SUM(CASE WHEN player1_id = ? THEN player2_score WHEN player2_id = ? THEN player1_score ELSE 0 END) AS goals_conceded,
          MAX(match_date) AS last_match_date
        FROM ladder_matches
        WHERE ((player1_id = ? AND player2_id = ?) OR (player1_id = ? AND player2_id = ?))`,
        [
          playerId, opponentId, playerId, opponentId,
          playerId, opponentId, playerId, opponentId,
          playerId, playerId,
          playerId, playerId,
          playerId, opponentId, opponentId, playerId
        ]
      );

      // Query elo difference from ladder_elo_history for matches between the two players
      const [eloRows] = await db.execute(
        `SELECT 
          SUM(CASE WHEN player_id = ? THEN delta ELSE 0 END) AS player_elo_gain,
          SUM(CASE WHEN player_id = ? THEN delta ELSE 0 END) AS opponent_elo_gain
        FROM ladder_elo_history
        WHERE match_id IN (
          SELECT id FROM ladder_matches
          WHERE (player1_id = ? AND player2_id = ?) OR (player1_id = ? AND player2_id = ?)
        )`,
        [playerId, opponentId, playerId, opponentId, opponentId, playerId]
      );

      const wins = matches[0].wins || 0;
      const losses = matches[0].losses || 0;
      const goalsScored = matches[0].goals_scored || 0;
      const goalsConceded = matches[0].goals_conceded || 0;
      const lastMatchDate = matches[0].last_match_date ? new Date(matches[0].last_match_date).toLocaleDateString('pt-PT') : 'N/A';
      const playerEloGain = eloRows[0].player_elo_gain || 0;
      const opponentEloGain = eloRows[0].opponent_elo_gain || 0;
      const eloDiff = playerEloGain - opponentEloGain;
      const totalMatches = Number(wins) + Number(losses);
      const winPercentage = totalMatches > 0 ? ((wins / totalMatches) * 100).toFixed(1) : '0.0';

      if (totalMatches === 0) {
        return await interaction.editReply(`Não tem jogos registados contra ${opponentUser.username}.`);
      }
      
      // Query last 5 matches between the two players ordered by date descending
      const [lastFiveMatches] = await db.execute(
        `SELECT player1_id, player2_id, player1_score, player2_score, penalty_score1, penalty_score2
         FROM ladder_matches
         WHERE (player1_id = ? AND player2_id = ?) OR (player1_id = ? AND player2_id = ?)
         ORDER BY match_date DESC
         LIMIT 5`,
        [playerId, opponentId, opponentId, playerId]
      );

      // Format last 5 games string
      let lastFiveGamesStr = '';
      for (const match of lastFiveMatches) {
        const p1 = match.player1_id === playerId ? (playerGamertag || user.username) : (opponentGamertag || opponentUser.username);
        const p2 = match.player2_id === playerId ? (playerGamertag || user.username) : (opponentGamertag || opponentUser.username);
        if (match.player1_score === match.player2_score) {
          lastFiveGamesStr += `${p1} ${match.player1_score} (${match.penalty_score1}) - (${match.penalty_score2}) ${match.player2_score} ${p2}\n`;
        } else {
          lastFiveGamesStr += `${p1} ${match.player1_score} - ${match.player2_score} ${p2}\n`;
        }
      }

      const replyWithLastFive = `📊 Registo Head-to-Head contra ${opponentUser.username}:\n\n` +
                    `🎮 **Jogos:** ${totalMatches} | ✅ **Vitórias:** ${wins} | ❌ **Derrotas:** ${losses}\n\n` +
                    `**Percentagem de Vitórias:** ${winPercentage}%\n\n` +
                    `**Golos Marcados:** ${goalsScored}\n` +
                    `**Golos Sofridos:** ${goalsConceded}\n` +
                    `**Diferença de Golos:** ${goalsScored - goalsConceded}\n\n` +
                    `📅 **Últimos 5 Jogos:**\n${lastFiveGamesStr}\n` +
                    `⏳ **Último Jogo:** ${lastMatchDate}\n` +
                    `⚖️ **Diferença de Elo contra o oponente:** ${eloDiff}`;

      await interaction.editReply(replyWithLastFive);
    } catch (error) {
      console.error('Error fetching head-to-head record:', error);
      await interaction.editReply('❌ An error occurred while fetching the head-to-head record.');
    } finally {
      await db.end();
    }
  }
};
