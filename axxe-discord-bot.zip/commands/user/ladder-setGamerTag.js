const { SlashCommandBuilder } = require('discord.js');
const mysql = require('mysql2/promise');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ladder-setgamertag')
    .setDescription('Defina o seu gamertag para poder entrar nas filas.')
    .addStringOption(option =>
      option.setName('gamertag')
        .setDescription('O seu gamertag')
        .setRequired(true)
    ),

  async execute(interaction) {
    const discordId = interaction.user.id;
    const gamertag = interaction.options.getString('gamertag').trim();

    if (!gamertag) {
      return await interaction.reply({
        content: languageService.getMessage('pt-PT', 'must_set_gamertag'),
        ephemeral: true
      });
    }

    try {
      const conn = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
      });

      // Check if user exists
      const [userRows] = await conn.execute(
        'SELECT id FROM users WHERE discord_id = ?',
        [discordId]
      );

      if (userRows.length === 0) {
        await conn.end();
        return await interaction.reply({
          content: languageService.getMessage('pt-PT', 'not_registered'),
          ephemeral: true
        });
      }

      // Update gamertag
      await conn.execute(
        'UPDATE users SET gamertag = ? WHERE discord_id = ?',
        [gamertag, discordId]
      );

      await conn.end();

      await interaction.reply({
        content: '✅ Gamertag definido com sucesso.',
        ephemeral: true
      });

    } catch (error) {
      console.error('❌ DB Error in /ladder-setGamerTag:', error);
      try {
      await interaction.reply({
        content: '❌ Erro ao definir o gamertag.',
        ephemeral: true
      });
      } catch (err) {
        console.error('❌ Secondary reply error:', err);
      }
    }
  }
};
