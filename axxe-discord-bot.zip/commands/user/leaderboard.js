const { SlashCommandBuilder } = require('discord.js');
const mysql = require('mysql2/promise');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Ver a classificação atual da ladder')
    .addStringOption(option =>
      option.setName('topx-players')
        .setDescription('Escolha o número de jogadores para mostrar')
        .setRequired(false)
        .addChoices(
          { name: 'Top 5', value: '5' },
          { name: 'Top 10', value: '10' },
          { name: 'Top 25', value: '25' }
        ))
    .addStringOption(option =>
      option.setName('filtrar')
        .setDescription('Filtrar tipos de jogadores')
        .setRequired(false)
        .addChoices(
          { name: 'Amigos', value: 'friends' },
          { name: 'AXXE Academy Students', value: 'academy' },
          { name: 'Jogadores Pro', value: 'pro' }
        )),

    async execute(interaction) {
      await interaction.deferReply({ ephemeral: true });

      const db = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
      });

    try {
      const topX = interaction.options.getString('topx-players') || '10';
      const filter = interaction.options.getString('filtrar');

      let filterCondition = '';
      let params = [];
      if (filter === 'friends') {
        // Assuming you have a way to get the user's friends IDs
        // Placeholder: We need user_id to filter friends, but no user_id available, so ignore filter for now
        params = [];
      } else if (filter === 'academy') {
        filterCondition = `AND u.is_academy_student = 1`;
        params = [];
      } else if (filter === 'pro') {
        filterCondition = `AND u.is_pro_player = 1`;
        params = [];
      }

      // Query to get player stats and elo history for current day
      // Fix duplication by selecting only the latest elo update per player for today
      let query = `
        SELECT u.username, u.gamertag, lps.*, eh.old_elo
        FROM ladder_player_stats lps
        JOIN users u ON lps.player_id = u.id
        LEFT JOIN (
          SELECT eh1.player_id, eh1.old_elo
          FROM ladder_elo_history eh1
          JOIN (
            SELECT player_id, MIN(changed_at) AS min_changed_at
            FROM ladder_elo_history
            WHERE DATE(changed_at) = CURDATE()
            GROUP BY player_id
          ) eh2 ON eh1.player_id = eh2.player_id AND eh1.changed_at = eh2.min_changed_at
        ) eh ON eh.player_id = lps.player_id
        WHERE 1=1
        ${filterCondition}
        ORDER BY lps.elo_rating DESC
        LIMIT ${parseInt(topX)}
      `;

      const [rows] = await db.execute(query);

      if (rows.length === 0) {
        return await interaction.editReply("❌ Ainda não há dados da ladder disponíveis para os filtros selecionados.");
      }

      let ladderText = '';

      // Add title before leaderboard
      ladderText += `## 🏆 Classificação da Ladder - Top ${topX}\n\n\n`;

      rows.forEach((player, index) => {
        const winstreakSymbol = player.win_streak && player.win_streak > 3 ? '🔥' : '';
        // Calculate elo variation if old_elo is available
        let eloVariation = '';
        if (player.old_elo !== null && player.old_elo !== undefined) {
          const diff = player.elo_rating - player.old_elo;
          eloVariation = diff >= 0 ? ` (+${diff})` : ` (${diff})`;
        }
        ladderText += `**#${index + 1} | ${player.elo_rating}${eloVariation} - ${player.gamertag} ${winstreakSymbol}**\n`;

        const formatWinPercentage = (value) => {
          if (Number.isInteger(value)) {
            return value.toString();
          } else {
            return value.toFixed(2);
          }
        };

        ladderText += `🎮 **J:** ${player.games_played} | **V:** ${player.wins} | **D:** ${player.losses} | **GM:** ${player.goals_scored || 0} | **GS:** ${player.goals_conceded || 0}  | **DG:** ${player.goal_diff} | **W%:** ${formatWinPercentage((player.wins/player.games_played)*100) || '0'}%\n\n`;
      });

      // Add note in smaller letters at the end
      ladderText += "_(as variações de elo apresentadas são valores diários. O 🔥 representa que o jogador está em winstreak (+ 3 vitórias consecutivas))_";

await interaction.editReply({ content: ladderText, ephemeral: true });
    } catch (err) {
      console.error('❌ Error loading leaderboard:', err.stack || err);
      await interaction.editReply("❌ Falha ao carregar a classificação.");
    }
  }
};
