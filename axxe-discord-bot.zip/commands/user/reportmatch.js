// commands/user/reportmatch.js
const { SlashCommandBuilder } = require('@discordjs/builders');
const mysql = require('mysql2/promise');
const { logCommand } = require('../../utils/logger');
const { getLadderIdByChannel } = require('../../utils/ladderChannelMapping');
const languageService = require('../../services/languageService');

const confirmationTimers = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reportmatch')
    .setDescription('Reportar o resultado de um jogo contra outro jogador.')
    .addIntegerOption(option =>
      option.setName('yourscore')
        .setDescription('O seu resultado')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('opponentscore')
        .setDescription('Resultado do adversário')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('penaltyscore1')
        .setDescription('Pontuação de penalidade do jogador 1 (opcional)')
        .setRequired(false))
    .addIntegerOption(option =>
      option.setName('penaltyscore2')
        .setDescription('Pontuação de penalidade do jogador 2 (opcional)')
        .setRequired(false)),

  async execute(interaction) {
    if (!interaction.channel.isThread()) {
      return interaction.reply({
        content: '❌ Este comando só pode ser usado em threads.',
        ephemeral: true
      });
    }

    let ladderId = null;
    if (interaction.channel.isThread()) {
      ladderId = await getLadderIdByChannel(interaction.channel.parentId);
    }
    if (!ladderId) {
      ladderId = await getLadderIdByChannel(interaction.channel.id);
    }
    if (!ladderId) {
      return interaction.reply({
        content: '❌ Este comando não pode ser usado neste canal.',
        ephemeral: true
      });
    }

    const matchIdMatch = interaction.channel.name.match(/^Match #(\d+)/);
    const matchId = matchIdMatch ? parseInt(matchIdMatch[1]) : NaN;

    const score1 = interaction.options.getInteger('yourscore');
    const score2 = interaction.options.getInteger('opponentscore');
    const penaltyScore1Raw = interaction.options.getInteger('penaltyscore1');
    const penaltyScore2Raw = interaction.options.getInteger('penaltyscore2');
    const reporterDiscordId = interaction.user.id;
    const reporterTag = interaction.user.tag;

    // Normalise penalty inputs to either number or null
    const norm = v => (v === undefined || v === null ? null : Number(v));
    let penaltyScore1 = norm(penaltyScore1Raw);
    let penaltyScore2 = norm(penaltyScore2Raw);

    const db = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });

    let replied = false;

    try {
      const [matchRows] = await db.execute('SELECT * FROM ladder_matches WHERE id = ? AND ladder_id = ?', [matchId, ladderId]);
      if (matchRows.length === 0) {
        if (!replied) {
          await interaction.reply({ content: '❌ Jogo não encontrado.', ephemeral: true });
          replied = true;
        }
        return;
      }

      const match = matchRows[0];

      if (match.status !== 'pending') {
        if (!replied) {
          await interaction.reply({
            content: '❌ Este jogo já foi confirmado e não pode ser alterado.',
            ephemeral: true
          });
          replied = true;
        }
        return;
      }

      const [playerRows] = await db.execute(
        'SELECT id, username FROM users WHERE discord_id = ?',
        [reporterDiscordId]
      );

      if (playerRows.length === 0) {
        if (!replied) {
          await interaction.reply({ content: '❌ Não está registado na ladder.', ephemeral: true });
          replied = true;
        }
        return;
      }

      const reporterPlayerId = playerRows[0].id;
      const opponentPlayerId = (match.player1_id === reporterPlayerId) ? match.player2_id : match.player1_id;
      const reporterIsPlayer1 = (match.player1_id === reporterPlayerId);

      const [opponentRows] = await db.execute(
        'SELECT username FROM users WHERE id = ?',
        [opponentPlayerId]
      );

      const opponentTag = opponentRows[0]?.username || 'Unknown';

      // =============================
      // ✅ NEW VALIDATION / BUSINESS LOGIC
      // =============================
      if (score1 !== score2) {
        // Regular win/loss — penalties must be ignored and NOT required
        penaltyScore1 = null;
        penaltyScore2 = null;
      } else {
        // Draw in regular time — must be decided on penalties
        if (penaltyScore1 === null || penaltyScore2 === null) {
          await interaction.reply({
            content: '❌ Jogo empatado no tempo regulamentar. Tem de indicar as penalidades de ambos os jogadores.',
            ephemeral: true
          });
          return;
        }
        if (penaltyScore1 === penaltyScore2) {
          await interaction.reply({
            content: '❌ Empates não são permitidos. O resultado deve ser uma vitória ou derrota. Por favor, reporte novamente.',
            ephemeral: true
          });
          return;
        }
        // Penalties provided and different -> proceed; the winner will be inferred downstream
      }
      // =============================

      // Persist reported scores (swap if reporter is player2)
      const valuesIfP1 = [score1, score2, penaltyScore1, penaltyScore2, 'pending', reporterPlayerId, matchId, ladderId];
      const valuesIfP2 = [score2, score1, penaltyScore2, penaltyScore1, 'pending', reporterPlayerId, matchId, ladderId];

      const [updateRes] = await db.execute(
        'UPDATE ladder_matches ' +
        'SET player1_score = ?, player2_score = ?, penalty_score1 = ?, penalty_score2 = ?, status = ?, reported_by = ? ' +
        'WHERE id = ? AND ladder_id = ? AND status = \'pending\'',
        reporterIsPlayer1 ? valuesIfP1 : valuesIfP2
      );
      if (updateRes.affectedRows === 0) {
        // Someone confirmed while we were preparing the report
        if (!replied) {
          await interaction.reply({
            content: '❌ Este jogo foi confirmado entretanto. O resultado não pode ser alterado.',
            ephemeral: true
          });
          replied = true;
        }
        return;
      }

      // Compose public confirmation message
      if (!replied) {
        let reportMessage;
        if (score1 !== score2) {
          reportMessage = `✅ Jogo reportado: ${reporterTag} ${score1} - ${score2} ${opponentTag}`;
        } else {
          // include penalties
          reportMessage = `✅ Jogo reportado: ${reporterTag} ${score1} (${penaltyScore1}) - (${penaltyScore2}) ${score2} ${opponentTag}`;
        }
        await interaction.reply({ content: reportMessage, ephemeral: false });
        replied = true;
      }

      const otherPlayerId = (match.player1_id === reporterPlayerId) ? match.player2_id : match.player1_id;

      const [otherPlayerRows] = await db.execute(
        'SELECT discord_id, username FROM users WHERE id = ?',
        [otherPlayerId]
      );
      const otherPlayerDiscordId = otherPlayerRows[0]?.discord_id || null;
      const otherPlayerUsername = otherPlayerRows[0]?.username || 'Unknown';

      const mention = otherPlayerDiscordId ? `<@${otherPlayerDiscordId}>` : otherPlayerUsername;

      await interaction.channel.send(
        `🕒 O resultado do jogo foi reportado por <@${reporterDiscordId}>.\n\n` +
        `Por favor, ${mention}, confirme o resultado usando o comando \`/confirmmatch\` nesta thread.\n\n` +
        `Se não confirmar em 5 minutos, o resultado será confirmado automaticamente.`
      );

      const client = interaction.client;
      const matchIdInt = matchId;
      const ladderIdInt = ladderId;
      const thread = interaction.channel;

      const timerMessage = await thread.send('⏳ A aguardar confirmação... 5:00 minutos restantes (timer dá update de 30 em 30 segundos).');

      let remainingSeconds = 300;
      const interval = setInterval(async () => {
        remainingSeconds -= 30;
        if (remainingSeconds >= 0) {
          const minutes = Math.floor(remainingSeconds / 30);
          const seconds = remainingSeconds % 30;
          try {
            // Fetch fresh thread to get latest archived status
            const freshThread = await thread.fetch();
            if (freshThread.archived) {
              try {
                await freshThread.setArchived(false);
                await new Promise(resolve => setTimeout(resolve, 500));
              } catch (err) {
                console.error('❌ Falha ao desarquivar a thread durante a atualização do temporizador:', err);
                return;
              }
            }
            const updatedThread = await thread.fetch();
            if (!updatedThread.archived) {
              try {
                await timerMessage.edit(`⏳ A aguardar confirmação... ${minutes}:${seconds.toString().padStart(2, '0')} minutos restantes (timer dá update de 30 em 30 segundos).`);
              } catch (editErr) {
                console.error('❌ Falha ao editar a mensagem do temporizador:', editErr);
              }
            } else {
              console.warn('⚠️ Thread is archived, skipping timer message edit.');
            }
          } catch (editErr) {
            console.error('❌ Falha ao editar a mensagem do temporizador:', editErr);
          }
        }
      }, 60000);

      const timeout = setTimeout(async () => {
        clearInterval(interval);
        const matchService = require('../../services/matchService');
        const currentMatch = await matchService.getMatchById(matchIdInt, ladderIdInt);
        if (currentMatch && currentMatch.status === 'pending') {
          const success = await matchService.confirmMatch(
            client,
            matchIdInt,
            ladderIdInt,
            thread,
            { source: 'auto' } // ✅ ensures auto footer
          );
                if (thread.archived) {
            try {
              await thread.setArchived(false);
              await new Promise(resolve => setTimeout(resolve, 500));
            } catch (err) {
              console.error('❌ Falha ao desarquivar a thread durante a confirmação automática:', err);
            }
          }
          try {
            if (success) {
              if (!thread.archived) {
                await timerMessage.edit('✅ Jogo confirmado automaticamente pelo sistema após 5 minutos.');
                try {
                  await thread.setArchived(true);
                } catch (err) {
                  console.error('❌ Falha ao arquivar a thread após a confirmação automática:', err);
                }
              } else {
                console.warn('⚠️ Thread is archived, skipping timer message edit after auto confirmation.');
              }
            } else {
              if (!thread.archived) {
                await timerMessage.edit('❌ Falha ao confirmar automaticamente o jogo.');
              } else {
                console.warn('⚠️ Thread is archived, skipping timer message edit after failed auto confirmation.');
              }
            }
          } catch (editErr) {
            console.error('❌ Falha ao editar a mensagem do temporizador após confirmação automática:', editErr);
          }
        } else {
          if (thread.archived) {
            try {
              await thread.setArchived(false);
              await new Promise(resolve => setTimeout(resolve, 500));
            } catch (err) {
              console.error('❌ Falha ao desarquivar a thread durante a atualização final do temporizador:', err);
            }
          }
          try {
            if (!thread.archived) {
              await timerMessage.edit('✅ Jogo já confirmado.');
            } else {
              console.warn('⚠️ Thread is archived, skipping timer message edit on final update.');
            }
          } catch (editErr) {
            console.error('❌ Falha ao editar a mensagem do temporizador na atualização final:', editErr);
          }
        }
      }, 300000);

      confirmationTimers.set(thread.id, { interval, timeout });

      // Logging (unchanged)
      const [reporterPlayerRows] = await db.execute(
        'SELECT gamertag, username as discordUsername, discord_id as discordUserId FROM users WHERE discord_id = ?',
        [reporterDiscordId]
      );
      const reporterPlayer = reporterPlayerRows[0] || { gamertag: 'Unknown', discordUsername: reporterTag, discordUserId: reporterDiscordId };

      const [opponentPlayerRows] = await db.execute(
        'SELECT gamertag, username as discordUsername, discord_id as discordUserId FROM users WHERE id = ?',
        [opponentPlayerId]
      );
      const opponentPlayer = opponentPlayerRows[0] || { gamertag: 'Unknown', discordUsername: opponentTag, discordUserId: null };

      await logCommand(interaction, `${reporterTag} reported a match: ${score1} - ${score2}` + (score1 === score2 ? ` (pens: ${penaltyScore1}-${penaltyScore2})` : ''), {
        threadId: interaction.channel.id,
        threadName: interaction.channel.name,
        matchInfo: {
          player1: reporterPlayer,
          player2: opponentPlayer,
          threadId: interaction.channel.id
        },
        matchResult: {
          result: `${reporterPlayer.gamertag} ${score1}${score1 === score2 ? ` (${penaltyScore1})` : ''} - ${score2}${score1 === score2 ? ` (${penaltyScore2})` : ''} ${opponentPlayer.gamertag}`
        }
      });

    } catch (err) {
      console.error('❌ Error in /reportmatch:', err);
      if (!replied) {
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({
            content: '❌ Erro na base de dados ao submeter o jogo.',
            ephemeral: true
          });
        } else {
          await interaction.reply({
            content: '❌ Erro na base de dados ao submeter o jogo.',
            ephemeral: true
          });
        }
        replied = true;
      }
    } finally {
      await db.end();
    }
  }
};

module.exports.confirmationTimers = confirmationTimers;
