// commands/user/status.js
const { SlashCommandBuilder } = require('discord.js');
const mysql = require('mysql2/promise');
const { getLadderIdByChannel } = require('../../utils/ladderChannelMapping');
require('dotenv').config();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Verifique a sua posição atual e atividade na fila de matchmaking.'),

  async execute(interaction) {
    const ladderId = await getLadderIdByChannel(interaction.channelId);
    if (!ladderId) {
      return await interaction.reply({
        content: '❌ Este comando não pode ser usado neste canal.',
        ephemeral: true
      });
    }

    const discordId = interaction.user.id;
    const username = interaction.user.tag;

    const conn = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });

    try {
      const [playerRows] = await conn.execute(
        'SELECT id FROM users WHERE discord_id = ?',
        [discordId]
      );

      if (playerRows.length === 0) {
        await conn.end();
        return await interaction.reply({
          content: '❌ Não está registado na ladder.',
          ephemeral: true
        });
      }

      const playerId = playerRows[0].id;

      const [queueRows] = await conn.execute(
        'SELECT looking_since FROM ladder_match_queue WHERE discord_id = ?',
        [discordId]
      );

      if (queueRows.length === 0) {
        await conn.end();
        return await interaction.reply({
          content: '❌ Não está na fila de matchmaking.',
          ephemeral: true
        });
      }

      const lookingSince = new Date(queueRows[0].looking_since);
      const now = new Date();
      const elapsedMs = now - lookingSince;
      const minutes = Math.floor(elapsedMs / 60000);
      const seconds = Math.floor((elapsedMs % 60000) / 1000);

      const [totalInQueue] = await conn.execute(
        'SELECT COUNT(*) as total FROM ladder_match_queue'
      );

      await conn.end();

      await interaction.reply({
        content:
          `📊 Entrou na fila há **${minutes}m ${seconds}s**.\n` +
          `👥 Atualmente há **${totalInQueue[0].total}** jogadores na fila.\n` +
          `⌛ Verifique o estado da fila.`,
        ephemeral: true
      });

    } catch (error) {
      console.error('❌ Error in /status:', error);
      await interaction.reply({
        content: '❌ Erro ao obter o estado da fila.',
        ephemeral: true
      });
    }
  }
};
