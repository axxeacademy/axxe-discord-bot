<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'axxegg_admin'); // or your actual DB user
define('DB_PASS', '0Z^pCF-^Un~l'); // use the correct password
define('DB_NAME', 'axxegg_teste');
define('DISCORD_CLIENT_ID', '1395691720779497565');
define('DISCORD_CLIENT_SECRET', 'fq4RY37hUo9FAVadhv4dYv_70kw56WyH');
define('DISCORD_REDIRECT_URI', 'https://ladder.axxe.gg/login.php');
define('DISCORD_BOT_TOKEN', 'YOUR_BOT_TOKEN'); // optional for server check
define('DISCORD_GUILD_ID', '1162767374785720393');
?>
