// services/queueService.js
const mysql = require('mysql2/promise');
require('dotenv').config();

async function getDBConnection() {
  return mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
  });
}

async function addToQueue(playerId, discordId, ladderId) {
  if (ladderId === undefined) throw new Error('ladderId is required');
  const conn = await getDBConnection();
  await conn.execute(
    'INSERT INTO ladder_match_queue (player_id, discord_id, ladder_id, looking_since) VALUES (?, ?, ?, NOW())',
    [playerId, discordId, ladderId]
  );
  await conn.end();
}

async function removeFromQueue(discordId, ladderId) {
  if (ladderId === undefined) throw new Error('ladderId is required');
  const conn = await getDBConnection();
  await conn.execute('DELETE FROM ladder_match_queue WHERE discord_id = ? AND ladder_id = ?', [discordId, ladderId]);
  await conn.end();
}

async function clearQueue(ladderId) {
  if (ladderId === undefined) throw new Error('ladderId is required');
  const conn = await getDBConnection();
  await conn.execute('DELETE FROM ladder_match_queue WHERE ladder_id = ?', [ladderId]);
  await conn.end();
}

async function getNextOpponent(discordId, playerElo, ladderId) {
  if (ladderId === undefined) throw new Error('ladderId is required');
  const conn = await getDBConnection();

  // Get the current player's looking_since
  let [myRows] = await conn.execute(
    `SELECT looking_since FROM ladder_match_queue WHERE discord_id = ? AND ladder_id = ? LIMIT 1`,
    [discordId, ladderId]
  );
  let myLookingSince = myRows.length > 0 ? myRows[0].looking_since : null;

  const now = new Date();
  const mySince = myLookingSince ? new Date(myLookingSince) : null;
  const myWaitMinutes = mySince ? (now - mySince) / 60000 : 0;

  // Define Elo thresholds based on waiting time
  let eloThreshold = 50; // initial ±50
  if (myWaitMinutes >= 5) {
    eloThreshold = 300;
  } else if (myWaitMinutes >= 2) {
    eloThreshold = 150;
  }

  // Try to find an opponent within the Elo threshold
  let [rows] = await conn.execute(
    `SELECT q.*, ps.elo_rating
     FROM ladder_match_queue q
     JOIN ladder_player_stats ps ON q.player_id = ps.player_id AND q.ladder_id = ps.ladder_id
     WHERE q.discord_id != ? AND q.ladder_id = ? AND ABS(ps.elo_rating - ?) <= ?
     ORDER BY q.looking_since ASC
     LIMIT 1`,
    [discordId, ladderId, playerElo, eloThreshold]
  );

  // If no opponent found and waiting less than 2 minutes, return no match
  if (rows.length === 0 && myWaitMinutes < 2) {
    await conn.end();
    return null;
  }

  // If no opponent found and waiting between 2 and 5 minutes, try again with expanded threshold (already done above)

  // If no opponent found and waiting more than 5 minutes, try to find any opponent who has also been waiting >5 minutes regardless of Elo difference
  if (rows.length === 0 && myWaitMinutes >= 5) {
    [rows] = await conn.execute(
      `SELECT q.*, ps.elo_rating
       FROM ladder_match_queue q
       JOIN ladder_player_stats ps ON q.player_id = ps.player_id AND q.ladder_id = ps.ladder_id
       WHERE q.discord_id != ? AND q.ladder_id = ? AND TIMESTAMPDIFF(MINUTE, q.looking_since, NOW()) >= 5
       ORDER BY q.looking_since ASC
       LIMIT 1`,
      [discordId, ladderId]
    );
    if (rows.length > 0) {
      const oppSince = new Date(rows[0].looking_since);
      const oppWaitMinutes = (now - oppSince) / 60000;
      if (oppWaitMinutes >= 5) {
        await conn.end();
        return rows[0];
      }
    }
  }

  await conn.end();
  return rows[0] || null;
}

module.exports = {
  addToQueue,
  removeFromQueue,
  clearQueue,
  getNextOpponent
};
