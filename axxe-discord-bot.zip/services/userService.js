// services/userService.js
const mysql = require('mysql2/promise');
require('dotenv').config();

/**
 * Fetch a user's gamertag by their Discord ID.
 * Returns the gamertag string or null if not found.
 */
async function getGamertagByDiscordId(discordId) {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
  });
  try {
    const [rows] = await conn.execute(
      'SELECT gamertag FROM users WHERE discord_id = ? LIMIT 1',
      [discordId]
    );
    return rows?.[0]?.gamertag || null;
  } finally {
    await conn.end().catch(() => {});
  }
}

module.exports = {
  getGamertagByDiscordId,
};
