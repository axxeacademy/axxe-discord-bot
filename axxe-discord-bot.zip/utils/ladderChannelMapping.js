// utils/ladderChannelMapping.js
const mysql = require('mysql2/promise');
require('dotenv').config();

async function getLadderIdByChannel(channelId) {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
  });

  try {
    const [rows] = await conn.execute(
      'SELECT ladder_id FROM discord_channel_ladders WHERE channel_id = ?',
      [channelId]
    );
    await conn.end();

    if (rows.length === 0) {
      return null; // No mapping found
    }
    return rows[0].ladder_id;
  } catch (error) {
    await conn.end();
    throw error;
  }
}

module.exports = {
  getLadderIdByChannel,
};
